@echo off
:: Caddy 실행 (창 숨김)
start "" /min caddy run --config Caddyfile
exit
