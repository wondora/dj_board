Set WshShell = CreateObject("WScript.Shell")
WshShell.Run "caddy run --config Caddyfile", 0, False
