@echo off
:: ============================================================
:: rclone WebDAV 서버 자동 실행 + HTTPS + 최적화 + 로그 + 방화벽 + 자동 재시작
:: ============================================================

:: -------------------- 설정 영역 --------------------
set RCLONE_EXE="C:\rclone\rclone.exe"
set REMOTE_PATH=E:\share
set ADDR=0.0.0.0:8443
set USER=1
set PASS=3895
set LOG_DIR=%~dp0logs
set TRANSFERS=16
set CHECKERS=16
set BUFFER=64M
:: HTTPS 인증서 경로 (자체 생성하거나 letsencrypt)
set CERT_FILE=%~dp0cert.pem
set KEY_FILE=%~dp0key.pem
:: -----------------------------------------------------

:: 로그 폴더 생성
if not exist "%LOG_DIR%" mkdir "%LOG_DIR%"

:: Windows 방화벽 허용
netsh advfirewall firewall add rule name="Rclone WebDAV" dir=in action=allow protocol=TCP localport=8443

:START
set DATESTAMP=%date:~-10,4%%date:~5,2%%date:~8,2%
set TIME_STAMP=%time:~0,2%-%time:~3,2%-%time:~6,2%
set LOG_FILE=%LOG_DIR%\rclone_%DATESTAMP%.log

echo [%DATESTAMP% %TIME_STAMP%] ===== Rclone WebDAV 서버 시작 ===== >> "%LOG_FILE%"

:: 서버 실행 (HTTPS + 최적화 옵션)
"%RCLONE_EXE%" serve webdav "%REMOTE_PATH%" --addr %ADDR% --user %USER% --pass %PASS% --cert "%CERT_FILE%" --key "%KEY_FILE%" --vfs-cache-mode writes --transfers %TRANSFERS% --checkers %CHECKERS% --buffer-size %BUFFER% >> "%LOG_FILE%" 2>&1

echo [%DATESTAMP% %TIME_STAMP%] ⚠️ 서버 종료됨, 5초 후 재시작 >> "%LOG_FILE%"
timeout /t 5
goto START
